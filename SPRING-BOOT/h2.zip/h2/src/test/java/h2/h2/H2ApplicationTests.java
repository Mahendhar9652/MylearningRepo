package h2.h2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2ApplicationTests {

	@Test
	void contextLoads() {
	}

}

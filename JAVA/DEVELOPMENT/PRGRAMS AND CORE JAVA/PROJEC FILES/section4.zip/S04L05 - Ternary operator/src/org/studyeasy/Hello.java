package org.studyeasy;
public class Hello {

	public static void main(String[] args) {
		int x = 10;
		
		x = (10 == x) ? 1 : 0;
		
		System.out.println(x);
     
	}

}

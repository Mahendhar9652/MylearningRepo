package org.studyeasy;
public class Hello {

	public static void main(String[] args) {
		int x = 6, y = 7;
		
           if(x >= y){
        	   System.out.println("true");
           }else{
        	   System.out.println("false");
           }
	}

}

package org.studyeasy;

public class Hello {

	public static void main(String[] args) {
		/*
		 * int x = 5; int y = 10;
		 * 
		 * if(!(x < y) || (x == y)){ System.out.println("Condition is TRUE");
		 * }else{ System.out.println("Condition is FALSE"); }
		 */

		int ageOfBoy = 36;
		int ageOfGirl = 25;

		if ((ageOfBoy >= 21) && (ageOfGirl >= 18)) {
			System.out.println("ready to get married!");

		} else {
			System.out.println("Wait for it kiddo!");
		}

	}

}

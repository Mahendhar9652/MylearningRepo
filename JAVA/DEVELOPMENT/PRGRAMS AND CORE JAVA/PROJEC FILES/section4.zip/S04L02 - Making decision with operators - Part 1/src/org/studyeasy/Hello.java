package org.studyeasy;
public class Hello {

	public static void main(String[] args) {
		int x = 4;
		
          if(x != 5){
        	  System.out.println("Value of x is not 5");
        	  
          }else{
          System.out.println("Value of x is 5");
          }
	}

}
